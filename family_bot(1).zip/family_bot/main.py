import os
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, 
    CommandHandler, 
    ContextTypes, 
    MessageHandler, 
    filters, 
    CallbackQueryHandler
)
from dotenv import load_dotenv
from database import Database

# Load environment variables
load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

db = Database()

# --- Helper: Check Admin ---
async def is_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type == "private":
        return True
    member = await context.bot.get_chat_member(update.effective_chat.id, update.effective_user.id)
    return member.status in ['administrator', 'creator']

# --- Basic Commands ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = (
        "🌹 *Family Management Bot (Rose-style)*\n\n"
        "I can help manage your group with notes, filters, and admin tools.\n\n"
        "🛠 *Admin Commands:*\n"
        "/setrules [text] - Set group rules\n"
        "/setwelcome [text] - Set welcome msg\n"
        "/warn - Warn a user (reply to msg)\n"
        "/resetwarns - Reset user warns\n"
        "/filter [keyword] [reply] - Auto-reply\n\n"
        "📝 *General Commands:*\n"
        "/rules - Show rules\n"
        "/save [name] - Save a note (reply to msg)\n"
        "/get [name] - Get a note\n"
        "/notes - List all notes\n"
        "/todo [task] - Add a task\n"
        "/list - Show tasks"
    )
    await update.message.reply_text(welcome_text, parse_mode='Markdown')

# --- Notes System ---
async def save_note(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await is_admin(update, context): return
    if not context.args or not update.message.reply_to_message:
        await update.message.reply_text("Usage: Reply to a message with `/save note_name`", parse_mode='Markdown')
        return
    
    note_name = context.args[0].lower()
    content = update.message.reply_to_message.text
    db.save_note(update.effective_chat.id, note_name, content)
    await update.message.reply_text(f"✅ Note '#{note_name}' saved!")

async def get_note(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args: return
    note_name = context.args[0].lower()
    content = db.get_note(update.effective_chat.id, note_name)
    if content:
        await update.message.reply_text(content)
    else:
        await update.message.reply_text("❌ Note not found.")

async def list_notes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    notes = db.list_notes(update.effective_chat.id)
    if not notes:
        await update.message.reply_text("No notes saved in this group.")
        return
    text = "📝 *Saved Notes:*\n" + "\n".join([f"• #{n}" for n in notes])
    await update.message.reply_text(text, parse_mode='Markdown')

# --- Filter System ---
async def add_filter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await is_admin(update, context): return
    if len(context.args) < 2:
        await update.message.reply_text("Usage: `/filter keyword reply_text`", parse_mode='Markdown')
        return
    keyword = context.args[0].lower()
    reply = " ".join(context.args[1:])
    db.add_filter(update.effective_chat.id, keyword, reply)
    await update.message.reply_text(f"✅ Filter added for '{keyword}'")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text: return
    
    text = update.message.text.lower()
    # Check Filters
    filters_list = db.get_filters(update.effective_chat.id)
    for keyword, reply in filters_list:
        if keyword in text:
            await update.message.reply_text(reply)
            return

# --- Moderation ---
async def warn_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await is_admin(update, context): return
    if not update.message.reply_to_message:
        await update.message.reply_text("Reply to a message to warn the user.")
        return
    
    user = update.message.reply_to_message.from_user
    count = db.add_warn(update.effective_chat.id, user.id)
    
    await update.message.reply_text(f"⚠️ {user.first_name} has been warned. ({count}/3)")
    
    if count >= 3:
        try:
            await context.bot.ban_chat_member(update.effective_chat.id, user.id)
            await update.message.reply_text(f"🚫 {user.first_name} banned for reaching 3 warnings.")
            db.reset_warns(update.effective_chat.id, user.id)
        except Exception as e:
            await update.message.reply_text(f"Failed to ban: {e}")

# --- Welcome & Rules ---
async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    for member in update.message.new_chat_members:
        settings = db.get_group_settings(update.effective_chat.id)
        msg = settings[0] if settings else "Welcome!"
        await update.message.reply_text(f"Hello {member.full_name}! {msg}")

async def set_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await is_admin(update, context): return
    rules = " ".join(context.args)
    if not rules: return
    db.update_group_settings(update.effective_chat.id, update.effective_chat.title, rules=rules)
    await update.message.reply_text("✅ Rules updated!")

async def show_rules(update: Update, context: ContextTypes.DEFAULT_TYPE):
    settings = db.get_group_settings(update.effective_chat.id)
    rules = settings[1] if settings else "No rules set."
    await update.message.reply_text(f"📜 *Rules:*\n\n{rules}", parse_mode='Markdown')

# --- Todo System ---
async def add_todo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    task = " ".join(context.args)
    if not task: return
    db.add_todo(update.effective_chat.id, task, update.effective_user.first_name)
    await update.message.reply_text(f"✅ Task added: {task}")

async def list_todos(update: Update, context: ContextTypes.DEFAULT_TYPE):
    todos = db.get_todos(update.effective_chat.id)
    if not todos:
        await update.message.reply_text("No pending tasks.")
        return
    text = "📋 *To-do List:*\n"
    keyboard = [[InlineKeyboardButton(f"Done: {t[1]}", callback_data=f"done_{t[0]}")] for t in todos]
    await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def todo_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data.startswith("done_"):
        db.complete_todo(int(query.data.split("_")[1]))
        await query.edit_message_text("✅ Task completed!")

if __name__ == '__main__':
    application = ApplicationBuilder().token(TOKEN).build()
    
    # Handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("save", save_note))
    application.add_handler(CommandHandler("get", get_note))
    application.add_handler(CommandHandler("notes", list_notes))
    application.add_handler(CommandHandler("filter", add_filter))
    application.add_handler(CommandHandler("warn", warn_user))
    application.add_handler(CommandHandler("setrules", set_rules))
    application.add_handler(CommandHandler("rules", show_rules))
    application.add_handler(CommandHandler("todo", add_todo))
    application.add_handler(CommandHandler("list", list_todos))
    application.add_handler(CallbackQueryHandler(todo_callback))
    application.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, welcome_new_member))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    print("Rose-style Family Bot is running...")
    application.run_polling()
