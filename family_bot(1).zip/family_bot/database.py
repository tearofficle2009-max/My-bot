import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_file="family_bot.db"):
        self.conn = sqlite3.connect(db_file, check_same_thread=False)
        self.create_tables()

    def create_tables(self):
        cursor = self.conn.cursor()
        
        # Table for Group Settings
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS groups (
                group_id INTEGER PRIMARY KEY,
                group_name TEXT,
                welcome_msg TEXT DEFAULT "Welcome to our family group!",
                rules TEXT DEFAULT "No rules set yet."
            )
        ''')

        # Table for Notes (/save note_name)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS notes (
                group_id INTEGER,
                note_name TEXT,
                content TEXT,
                PRIMARY KEY (group_id, note_name)
            )
        ''')

        # Table for Filters (Auto-replies)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS filters (
                group_id INTEGER,
                keyword TEXT,
                reply TEXT,
                PRIMARY KEY (group_id, keyword)
            )
        ''')

        # Table for Warnings
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS warnings (
                group_id INTEGER,
                user_id INTEGER,
                warn_count INTEGER DEFAULT 0,
                PRIMARY KEY (group_id, user_id)
            )
        ''')

        # Table for To-do List
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS todos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                task TEXT,
                status TEXT DEFAULT "pending",
                created_by TEXT,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        self.conn.commit()

    # --- Notes Methods ---
    def save_note(self, group_id, note_name, content):
        cursor = self.conn.cursor()
        cursor.execute('INSERT OR REPLACE INTO notes (group_id, note_name, content) VALUES (?, ?, ?)', (group_id, note_name, content))
        self.conn.commit()

    def get_note(self, group_id, note_name):
        cursor = self.conn.cursor()
        cursor.execute('SELECT content FROM notes WHERE group_id = ? AND note_name = ?', (group_id, note_name))
        res = cursor.fetchone()
        return res[0] if res else None

    def list_notes(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT note_name FROM notes WHERE group_id = ?', (group_id,))
        return [row[0] for row in cursor.fetchall()]

    # --- Filters Methods ---
    def add_filter(self, group_id, keyword, reply):
        cursor = self.conn.cursor()
        cursor.execute('INSERT OR REPLACE INTO filters (group_id, keyword, reply) VALUES (?, ?, ?)', (group_id, keyword, reply))
        self.conn.commit()

    def get_filters(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT keyword, reply FROM filters WHERE group_id = ?', (group_id,))
        return cursor.fetchall()

    # --- Warnings Methods ---
    def add_warn(self, group_id, user_id):
        cursor = self.conn.cursor()
        cursor.execute('INSERT OR IGNORE INTO warnings (group_id, user_id, warn_count) VALUES (?, ?, 0)', (group_id, user_id))
        cursor.execute('UPDATE warnings SET warn_count = warn_count + 1 WHERE group_id = ? AND user_id = ?', (group_id, user_id))
        cursor.execute('SELECT warn_count FROM warnings WHERE group_id = ? AND user_id = ?', (group_id, user_id))
        self.conn.commit()
        return cursor.fetchone()[0]

    def reset_warns(self, group_id, user_id):
        cursor = self.conn.cursor()
        cursor.execute('UPDATE warnings SET warn_count = 0 WHERE group_id = ? AND user_id = ?', (group_id, user_id))
        self.conn.commit()

    # --- Group Settings ---
    def update_group_settings(self, group_id, group_name, welcome_msg=None, rules=None):
        cursor = self.conn.cursor()
        cursor.execute('INSERT OR IGNORE INTO groups (group_id, group_name) VALUES (?, ?)', (group_id, group_name))
        if welcome_msg:
            cursor.execute('UPDATE groups SET welcome_msg = ? WHERE group_id = ?', (welcome_msg, group_id))
        if rules:
            cursor.execute('UPDATE groups SET rules = ? WHERE group_id = ?', (rules, group_id))
        self.conn.commit()

    def get_group_settings(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT welcome_msg, rules FROM groups WHERE group_id = ?', (group_id,))
        return cursor.fetchone()

    def add_todo(self, group_id, task, created_by):
        cursor = self.conn.cursor()
        cursor.execute('INSERT INTO todos (group_id, task, created_by) VALUES (?, ?, ?)', (group_id, task, created_by))
        self.conn.commit()

    def get_todos(self, group_id):
        cursor = self.conn.cursor()
        cursor.execute('SELECT id, task, status, created_by FROM todos WHERE group_id = ? AND status = "pending"', (group_id,))
        return cursor.fetchall()

    def complete_todo(self, todo_id):
        cursor = self.conn.cursor()
        cursor.execute('UPDATE todos SET status = "completed" WHERE id = ?', (todo_id,))
        self.conn.commit()
