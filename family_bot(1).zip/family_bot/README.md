# Telegram Family Bot (Rose-style)

This is a Telegram bot designed for family groups, inspired by the features of @MissRose_bot. It includes group management functionalities like notes, filters (auto-replies), moderation (warn/ban), and a shared to-do list.

## Features

*   **Notes System**: Save and retrieve important information using `/save`, `/get`, and `/notes`.
*   **Filters (Auto-reply)**: Set up custom keywords that the bot will automatically respond to.
*   **Moderation**: Admins can warn users, and the bot can automatically ban users after a certain number of warnings.
*   **Welcome & Rules**: Customizable welcome messages for new members and group rules.
*   **Shared To-Do List**: Create and manage shared tasks for the family.

## Setup Guide

### Step 1: Get Your Bot Token

1.  Open Telegram and search for `@BotFather`.
2.  Send `/newbot` to BotFather.
3.  Follow the instructions to choose a name and username for your bot.
4.  BotFather will give you an API Token. **Save this token securely.** It looks something like `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`.

### Step 2: Prepare Your VPS

Log in to your VPS via SSH.

### Step 3: Download the Bot Files

```bash
git clone https://github.com/YOUR_USERNAME/family_bot.git # Replace with your repo if you fork
cd family_bot
```

### Step 4: Configure Your Bot

1.  Rename `.env.example` to `.env`:
    ```bash
    mv .env.example .env
    ```
2.  Edit the `.env` file and replace `your_bot_token_here` with your actual Telegram Bot Token:
    ```bash
    nano .env
    # TELEGRAM_TOKEN=your_bot_token_here
    ```
    Press `Ctrl+X`, then `Y`, then `Enter` to save and exit `nano`.

### Step 5: Run the Bot

You have two options to run the bot: using Docker (recommended) or directly with Python.

#### Option A: Using Docker (Recommended)

Docker provides an isolated and easy-to-manage environment for your bot.

1.  **Install Docker and Docker Compose** (if not already installed):
    ```bash
    sudo apt update
    sudo apt install docker.io docker-compose -y
    sudo systemctl start docker
    sudo systemctl enable docker
    ```
2.  **Build and Run the Bot**:
    ```bash
    docker-compose up --build -d
    ```
    This command will build the Docker image, create the container, and run it in detached mode (`-d`).

3.  **Check Bot Status**:
    ```bash
    docker-compose logs -f
    ```
    To stop the bot:
    ```bash
    docker-compose down
    ```

#### Option B: Running Directly with Python

1.  **Install Python and pip** (if not already installed):
    ```bash
    sudo apt update
    sudo apt install python3 python3-pip -y
    ```
2.  **Install Dependencies**:
    ```bash
    pip3 install -r requirements.txt
    ```
3.  **Run the Bot**:
    ```bash
    python3 main.py
    ```
    To keep the bot running in the background, you can use `screen` or `nohup`:
    ```bash
    # Using screen
    screen -S family_bot
    python3 main.py
    # Press Ctrl+A then D to detach from screen

    # To re-attach:
    screen -r family_bot
    ```

### Step 6: Add the Bot to Your Group

1.  Open Telegram and search for your bot by its username.
2.  Start a chat with your bot.
3.  Add your bot to your family group.
4.  **Make the bot an administrator** in the group to enable moderation features and welcome messages.

## Usage

Once the bot is running and added to your group as an admin, you can use the commands listed in the `/start` message.

Enjoy your new Family Bot! 🎉
